import jwt from "jsonwebtoken";




export const sendToken = (payload, privateKey) => {
    const token = jwt.sign(payload, privateKey || process.env.JWT_SECRET, { expiresIn: "1h" });
    return token;
    next();
}


export const verifyToken = (req, res, next) => {
    try {
        const token = req.header("token")
        if (!token) {
            throw new Error("Token not found");
        }
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.userId = decoded.userId;
    } catch (error) {
        throw new Error("Invalid token");
    }
    next();
}